package com.crud.app;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.crud.app.model.Admin;
import com.crud.app.repository.AdminRepository;
import com.crud.app.services.AdminService;


@RunWith(SpringRunner.class)
@SpringBootTest
public class AdminTest 
{
	@Autowired
	private AdminService service;
	
	@MockBean
	private AdminRepository repository;
	
	@Test
	public void listAllTest()
	{
		when(repository.findAll()).thenReturn(Stream
						.of(new Admin(1, "Mon", "65659595", "fy@g.com", "fy"), 
							new Admin(2, "Roro", "65649595", "ro@g.com", "ro")).collect(Collectors.toList()));
		assertEquals(2, service.listAll().size());
	}
	
	@Test
	public void saveTest()
	{
		Admin p1 = new Admin(3, "Ace", "65645595", "ace@g.com", "ace");
		service.save(p1);
		verify(repository, times(1)).save(p1);
	}
	
	@Test
	public void updateTest()
	{
		Admin p1 = new Admin(3, "Ace", "65645595", "ace@g.com", "ace");
		service.save(p1);
		verify(repository, times(1)).save(p1);
	}
	
	@Test
	public void deleteTest()
	{
		int id = 1;
		service.delete(id);
		verify(repository, times(1)).deleteById(id);
	}
}
