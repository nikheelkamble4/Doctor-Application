package com.crud.app;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.crud.app.model.Patient;
import com.crud.app.repository.PatientRepository;
import com.crud.app.services.PatientService;


@RunWith(SpringRunner.class)
@SpringBootTest
public class PatientTest 
{
	@Autowired
	private PatientService service;
	
	@MockBean
	private PatientRepository repository;
	
	@Test
	public void listAllTest()
	{
		when(repository.findAll()).thenReturn(Stream
						.of(new Patient(1, "Monkey D. Luffy", "65659595", "luffy@g.com", "luffy", "B+", "male", 25, "Bangalore"), 
							new Patient(2, "Roronoa Zoro", "65649595", "zoro@g.com", "zoro", "B+", "male", 25, "Bangalore")).collect(Collectors.toList()));
		assertEquals(2, service.listAll().size());
	}
	
	@Test
	public void saveTest()
	{
		Patient p1 = new Patient(3, "Portgas D. Ace", "65645595", "ace@g.com", "ace", "B+", "male", 25, "Bangalore");
		service.save(p1);
		verify(repository, times(1)).save(p1);
	}
	
	@Test
	public void updateTest()
	{
		Patient p1 = new Patient(3, "Portgas D. Ace", "65645595", "ace@g.com", "ace", "B+", "male", 25, "Bangalore");
		service.save(p1);
		verify(repository, times(1)).save(p1);
	}
	
	@Test
	public void deleteTest()
	{
		int id = 1;
		service.delete(id);
		verify(repository, times(1)).deleteById(id);
	}
	
}
